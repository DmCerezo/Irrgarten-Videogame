# frozen_string_literal: true
module Irrgarten
  class PlayerSquare

    def initialize(player, row, col)
      @player = player
      @row = row
      @col = col
    end
  end
end
