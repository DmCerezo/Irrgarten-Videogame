# frozen_string_literal: true
module Irrgarten
  class Labyrinth
    @@BLOCK_CHAR = 'X'
    @@EMPTY_CHAR = '-'
    @@MONSTER_CHAR = 'M'
    @@COMBAT_CHAR = 'C'
    @@EXIT_CHAR = 'E'
    @@ROW
    @@COL

    def initialize(nRows, nCols, exitRow, exitCol)
      @nRows = nRows
      @nCols = nCols
      @exitRow = exitRow
      @exitCol = exitCol

      @monsters = Array.new(@nRows){Array.new(@nCols, nil)}
      @players = [] #array de PlayerSquare
      for i in 0..@nRows-1
        for j in 0..@nCols-1
          @players << PlayerSquare.new(i,j,nil)
        end
      end
      @labyrinth = Array.new(@nRows){Array.new(@nCols, @@EMPTY_CHAR)

      @labyrinth[@exitRow][@exitCol] = @@EXIT_CHAR





    end
  end
end